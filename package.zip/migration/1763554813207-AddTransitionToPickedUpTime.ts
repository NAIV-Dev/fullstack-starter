import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTransitionToPickedUpTime1763554813207 implements MigrationInterface {
    name = 'AddTransitionToPickedUpTime1763554813207'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`Transaksi\` ADD \`transition_to_picked_up_ts\` timestamp NULL`);
        await queryRunner.query(`ALTER TABLE \`User\` CHANGE \`is_active\` \`is_active\` tinyint NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE \`Layanan\` CHANGE \`is_active\` \`is_active\` tinyint NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE \`Transaksi\` CHANGE \`sudah_lunas\` \`sudah_lunas\` tinyint NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE \`Transaksi\` CHANGE \`sudah_diambil\` \`sudah_diambil\` tinyint NULL DEFAULT false`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`Transaksi\` CHANGE \`sudah_diambil\` \`sudah_diambil\` tinyint NULL DEFAULT '0'`);
        await queryRunner.query(`ALTER TABLE \`Transaksi\` CHANGE \`sudah_lunas\` \`sudah_lunas\` tinyint NULL DEFAULT '0'`);
        await queryRunner.query(`ALTER TABLE \`Layanan\` CHANGE \`is_active\` \`is_active\` tinyint NOT NULL DEFAULT '1'`);
        await queryRunner.query(`ALTER TABLE \`User\` CHANGE \`is_active\` \`is_active\` tinyint NOT NULL DEFAULT '1'`);
        await queryRunner.query(`ALTER TABLE \`Transaksi\` DROP COLUMN \`transition_to_picked_up_ts\``);
    }

}
