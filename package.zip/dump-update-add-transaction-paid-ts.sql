ALTER TABLE `Transaksi` ADD `transition_to_paid_ts` timestamp NULL
ALTER TABLE `Transaksi` ADD `transition_to_picked_up_ts` timestamp NULL
