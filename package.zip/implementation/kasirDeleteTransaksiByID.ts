import { T_kasirDeleteTransaksiByID } from "../types/api/kasirDeleteTransaksiByID";

export const kasirDeleteTransaksiByID: T_kasirDeleteTransaksiByID = async req => {
  throw new Error('Kasir is no longer able to delete transaction');
}
