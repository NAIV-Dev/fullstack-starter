
import { Layanan } from '../model/table/Layanan'

export interface T_kasirGetLayanan_headers {
  authorization: string
}
export interface T_kasirGetLayanan_query {
  keyword?: string
  limit?: number
  offset?: number
  is_active?: boolean
}
interface ReturnType_0 {
  total: number
  data: Layanan[]
}

export type T_kasirGetLayanan = (request: {
  headers: T_kasirGetLayanan_headers
  query: T_kasirGetLayanan_query
}, base_url?: string) => Promise<ReturnType_0>;

export const method = 'get';
export const url_path = '/kasir/layanan';
export const alias = 'kasirGetLayanan';
