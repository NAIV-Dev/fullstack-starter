
export interface JenisPengeluaran {
  id: number;
  label: string;
  deskripsi?: string;
  created_at: Date;
  deleted_at?: Date;
}