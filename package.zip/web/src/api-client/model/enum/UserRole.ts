export enum UserRole {
  'Admin' = 'Admin',
  'Kasir' = 'Kasir',
};