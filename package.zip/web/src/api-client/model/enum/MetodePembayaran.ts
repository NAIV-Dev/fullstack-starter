export enum MetodePembayaran {
  'QRIS' = 'QRIS',
  'Tunai' = 'Tunai',
  'TransferBank' = 'TransferBank',
};