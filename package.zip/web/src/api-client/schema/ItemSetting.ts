

export interface ItemSetting {
  key: string
  value: string
}