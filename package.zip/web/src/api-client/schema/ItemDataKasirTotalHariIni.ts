

export interface ItemDataKasirTotalHariIni {
  nama_layanan: string
  label_satuan: string
  jumlah?: number
}